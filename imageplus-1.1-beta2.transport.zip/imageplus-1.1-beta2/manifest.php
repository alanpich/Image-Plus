<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '117e8db4ff037363c97b9cb529bf55b1',
      'native_key' => 'imageplus',
      'filename' => 'modNamespace/96b12517d41040751c1f5c2e99845fbe.vehicle',
      'namespace' => 'imageplus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e7b76529bc678ba5c3f3d33f210601b4',
      'native_key' => 1,
      'filename' => 'modCategory/5d7cae6a80f1ff8019a5319a9b2721f5.vehicle',
      'namespace' => 'imageplus',
    ),
  ),
);