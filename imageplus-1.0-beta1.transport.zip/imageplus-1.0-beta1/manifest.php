<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cde9041ce09fa4f95b2dd1675ec324f2',
      'native_key' => 'imageplus',
      'filename' => 'modNamespace/72963dad7eb2fee927d54304fa1f7e4b.vehicle',
      'namespace' => 'imageplus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '93516803bb2f7ab7cd9b0fa91b246428',
      'native_key' => 1,
      'filename' => 'modCategory/1602a78f707c4de7bd1f7650964aa19f.vehicle',
      'namespace' => 'imageplus',
    ),
  ),
);