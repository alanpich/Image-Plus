<?php

	define("ImagePlusCore",$modx->getOption('core_path').'components/ImagePlus/');
	define("ImagePlusAssets",$modx->getOption('manager_url').'assets/components/ImagePlus/');


?>
