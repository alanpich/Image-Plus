<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f82f83efd9f4f7e085bce9203dec1b3e',
      'native_key' => 'imageplus',
      'filename' => 'modNamespace/08c55ec618b306ac258ff896c2553cd9.vehicle',
      'namespace' => 'imageplus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4c6b76638071ce85d5a54ee7aa192051',
      'native_key' => 1,
      'filename' => 'modCategory/98b54c72408076d516e0a17891bb9996.vehicle',
      'namespace' => 'imageplus',
    ),
  ),
);